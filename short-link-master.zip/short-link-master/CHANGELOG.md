# Changelog

## 0.2.1 (2018-12-26)

You can upgrade to this version from 0.2.x smoothly

- Add property `US_VERSION` for future updates check
- Bug fix in query log part (null value for some keys)
- Some other minor updates

## 0.2.0 (2018-12-24)

- Refactor
- Add user system
- Log query history for later analytics