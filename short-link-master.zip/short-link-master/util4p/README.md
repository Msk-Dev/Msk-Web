# utilities for php

Require PHP version >= 5.1.0

## AccessController.class.php

## CRLogger.class.php

## CRObject.class.php

## MysqlPDO.class.php

## Random.class.php

## RedisDAO.class.php

## Session.class.php

## SQLBuilder.class.php

## util.php

## Validator.class.php
