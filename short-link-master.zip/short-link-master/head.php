<meta charset="utf-8"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<meta name="keywords" content="短网址,短链接,短网址生成器,LinkShortener,URL Shortener,short url,Link Shortener,自定义短网址"/>
<meta name="description" content="短网址,短网址生成器,LinkShortener,short link,short url,Link Shortener,访问量统计,有效期设置,自定义短网址"/>
<meta name="author" content="Newnius"/>
<link rel="icon" href="static/favicon.ico"/>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" rel="stylesheet"/>
<link href="static/style.css" rel="stylesheet"/>
<link href="https://cdn.jsdelivr.net/npm/eonasdan-bootstrap-datetimepicker@4.17.47/build/css/bootstrap-datetimepicker.min.css" rel="stylesheet"/>

<script src="https://cdn.jsdelivr.net/npm/jquery@3.3.1/dist/jquery.min.js"></script>